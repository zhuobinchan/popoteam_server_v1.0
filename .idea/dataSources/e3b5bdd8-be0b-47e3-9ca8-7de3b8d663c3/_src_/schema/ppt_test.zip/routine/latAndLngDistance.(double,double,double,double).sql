CREATE FUNCTION `latAndLngDistance`(`lng1` DOUBLE, `lat1` DOUBLE, `lng2` DOUBLE, `lat2` DOUBLE)
  RETURNS DOUBLE
BEGIN

    DECLARE distance DOUBLE;
    DECLARE earth_radius BIGINT;
    DECLARE radLat1 DOUBLE;
    DECLARE radLat2 DOUBLE;
    DECLARE latDiff DOUBLE;
    DECLARE lngDiff DOUBLE;

    SET earth_radius = 6378137;
    SET radLat1 = lat1 * pi() / 180.0;
    SET radLat2 = lat2 * pi() / 180.0;
    SET latDiff = radLat1 - radLat2;
    SET lngDiff = lng1 * pi() / 180.0 - lng2 * pi() / 180.0;

    SET distance = 2 * asin(sqrt(POW(sin(latDiff / 2), 2) +
                                 cos(radLat1) * cos(radLat2) * POW(sin(lngDiff / 2), 2)));
    SET distance = distance * earth_radius;
    SET distance = round(distance * 10000) / 10000;

    RETURN distance;
  END